const express = require('express');
const router = express.Router();
const Joi = require('joi');
const bcrypt = require('bcrypt');
const { generateAccessToken } = require('../middlewares/Auth');
const User = require('../models/userModel');

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required()
});

const registrationSchema = Joi.object({
    name: Joi.string().alphanum().min(3).max(30).required(),
    password: Joi.string().min(8).required(),
    email: Joi.string().email().required(),
    role: Joi.string().alphanum().min(3).max(30)
  });
  

  router.post('/register', async (req, res) => {
    try {
      // Validate input
      const { error, value } = registrationSchema.validate(req.body);
      if (error) {
        return res.status(400).json({ error: error.details[0].message });
      }
      const hashedPassword = await bcrypt.hash(value.password, 10);
      // Create new user
      const newUser = new User({
        name: value.name,
        password: hashedPassword ,
        email: value.email,
        role: value.role
      });
  
      // Save user to database
      await newUser.save();
      
      // Send success response
      res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  


  router.post('/login', async (req, res) => {
    try {
      // Validate input
      const { error, value } = loginSchema.validate(req.body);
      if (error) {
        return res.status(400).json({ error: error.details[0].message });
      }
  
      // Find user by email
      const user = await User.findOne({ email: value.email });
      if (!user) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }
  
      // Check password
      const validPassword = await bcrypt.compare(value.password, user.password);
      if (!validPassword) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }
  
      // Generate token
      const token = generateAccessToken({ name: user.name, email: user.email });
      res.cookie('access_token', token, {
        httpOnly: true,
        maxAge: 3600000 // 1 hour in milliseconds
      });
      // Send success response with token
      res.json({ message: 'Logged in successfully', token });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  

module.exports = router;
