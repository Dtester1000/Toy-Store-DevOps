// userModel.js
const mongoose = require('mongoose');
const Joi = require('joi');
const jwt = require('jsonwebtoken');


const { Schema } = mongoose;

const userSchema = new Schema({
  name: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  role:{
    type: String,
    required: true,
    default: "user"
  },
    user_id:{
      type: String,
      
      
  }},
  
  {timestamps:true});

const User = mongoose.model('Users', userSchema);

module.exports = User;
